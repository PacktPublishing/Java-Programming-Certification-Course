// while loop in Java
// Code by Studyopedia

class Demo37 {
    public static void main(String[] args) {

        int  i = 5;

        while (i < 10) {
            System.out.println(i);
            i++;
        }
    }
}