// continue statement in Java
// example 2
// Code by Studyopedia

class Demo44 {
    public static void main(String[] args) {

        for (int i = 1; i <= 10; i++) {
            if (i % 2 == 0) {
                continue; // skip even numbers
            }
            System.out.println("Odd Number = "+i);
        }
    }
}